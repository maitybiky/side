import React from 'react'
import Products from '../Component/Products'


const Home = () => {
  return (
    <>
    <br />
    <h1 className='txtcenter fnt'>Home</h1>
    
    <Products/>
    </>
  )
}

export default Home