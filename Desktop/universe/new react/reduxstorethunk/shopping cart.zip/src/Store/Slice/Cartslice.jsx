import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "Cart",
  initialState: [],
  reducers: {
    addTocart(state, action) {
      state.push(action.payload);
    },
    removeFromcart(state, action) {
      return state.filter((cart) => cart.id !== action.payload);
    },
    increaseQty(state, action) {
        const index = state.findIndex(c=>c.id===action.payload)
      state[index].quantity += 1;
    }, 
    decreaseQty(state, action) {
        const index = state.findIndex(c=>c.id===action.payload)
       
      state[index].quantity -= 1;
    },
  },
});

export default cartSlice.reducer;
export const { addTocart, removeFromcart, increaseQty ,decreaseQty } = cartSlice.actions;
