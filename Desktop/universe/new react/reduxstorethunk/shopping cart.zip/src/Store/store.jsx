import { configureStore } from "@reduxjs/toolkit";
import cartreducer from "./Slice/Cartslice";
import prodreducer from "./Slice/Productslice";
import Authslice from "../Redux/Slice/Authslice";
export const Store = configureStore({
  reducer: {
    product: prodreducer,
    cart: cartreducer,
    auth : Authslice
  },
});
