import React from 'react'

const Footer = () => {
  return (
    <div style={{height:30}} className='txtalign'>

    </div>
  )
}

export default Footer